module.exports = {
  database: {
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'postgres',
    database: process.env.DB_NAME || 'this_socks',
    max: 50
  },
  email: {
    host: 'smtp.gmail.com',
    port: 465,
    secure: true,
    auth: {
      user: 'joaomanoellins2@gmail.com',
      pass: 'zarK499(Kt,eTfdNke6uCVmshJMCo@F{VHq2tMn8AAWxH7y2JawvdLvcj72gMx+A'
    }
  }
}
