const db = require('../db')
module.exports = () => {
  return {
    getRecommendedProducts(sku, callback) {
      const text = `
        SELECT p.*, m.id as model_id, m.sku, m.size, m.color
        FROM recommendation r, model m, product p
        WHERE r.category_id = (
          SELECT category_id 
          FROM recommendation
          WHERE sku = $1
        ) 
        AND r.sku = m.sku
        AND m.product_id = p.id
        ORDER BY r.sales_number 
        LIMIT 5; 
      `
      
      db().query(text, [sku], callback)
    },
    getRecommendedProductsByCategory(categoryId, callback) {
      const text = `
        SELECT p.*, m.id as model_id, m.sku, m.size, m.color
        FROM recommendation r, model m, product p
        WHERE r.category_id = $1
        AND r.sku = m.sku
        AND m.product_id = p.id
        ORDER BY r.sales_number 
        LIMIT 5; 
      `

      db().query(text, [categoryId], callback)
    },
    updateSalesNumber(sku, callback) {
      const text = `
        UPDATE recommendation 
        SET sales_number = sales_number + 1
        WHERE sku = $1
      `
      db().query(text, [sku], callback)
    },
    createRecommendation(params, callback) {
      const text = `
        INSERT INTO recommendation 
          (category_id, sku) 
        VALUES ($1,$2)
      `
      db().query(text, [params.categoryId, params.sku], callback)
    }
  }
}